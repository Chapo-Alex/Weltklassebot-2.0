from __future__ import annotations

import importlib.util
import pathlib
import sys
from datetime import UTC, datetime, timedelta
from types import SimpleNamespace

try:
    from hypothesis import given, strategies as st
except ModuleNotFoundError:  # pragma: no cover - offline fallback
    stub_name = "_hypothesis_stub"
    if stub_name in sys.modules:
        module = sys.modules[stub_name]
    else:
        stub_path = pathlib.Path(__file__).resolve().parents[1] / "_hypothesis_stub.py"
        spec = importlib.util.spec_from_file_location(stub_name, stub_path)
        module = importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        sys.modules[stub_name] = module
        spec.loader.exec_module(module)
    given = module.given
    st = module.strategies

from strategy.breakout_bias import BreakoutBiasStrategy, StrategyConfig


def _build_ns_candle(
    symbol: str,
    index: int,
    open_price: float,
    close_price: float,
    high_price: float | None = None,
    low_price: float | None = None,
) -> SimpleNamespace:
    start = datetime(2024, 1, 1, tzinfo=UTC) + timedelta(minutes=index)
    return SimpleNamespace(
        symbol=symbol,
        open=open_price,
        close=close_price,
        high=high_price if high_price is not None else max(open_price, close_price),
        low=low_price if low_price is not None else min(open_price, close_price),
        start=start,
        end=start + timedelta(minutes=1),
        volume=1.0,
    )


def test_percentile_threshold_monotonicity() -> None:
    candles = [
        _build_ns_candle(
            "ETHUSDT",
            idx,
            100.0 + idx,
            101.5 + idx,
            high_price=102 + idx,
            low_price=99 + idx,
        )
        for idx in range(8)
    ]
    base_config = dict(
        breakout_threshold=0.0,
        order_size=0.2,
        pyramid_steps=(1.0,),
        threshold_mode="percentile",
        threshold_lookback=4,
    )
    low_threshold = BreakoutBiasStrategy(
        StrategyConfig(threshold_percentile=0.25, **base_config)
    )
    high_threshold = BreakoutBiasStrategy(
        StrategyConfig(threshold_percentile=0.75, **base_config)
    )

    low_orders = [o for o in low_threshold.generate_orders(candles) if o.side == "buy"]
    high_orders = [o for o in high_threshold.generate_orders(candles) if o.side == "buy"]

    assert len(high_orders) <= len(low_orders)


def test_atr_regime_threshold_respects_high_volatility() -> None:
    candles = []
    price = 100.0
    for idx in range(10):
        close = price * (1.01 if idx % 2 == 0 else 1.02)
        high = max(price, close) + (5.0 if idx >= 4 else 1.0)
        low = min(price, close) - (5.0 if idx >= 4 else 1.0)
        candles.append(_build_ns_candle("BTCUSDT", idx, price, close, high, low))
        price = close

    base_config = dict(
        breakout_threshold=0.0,
        order_size=0.5,
        pyramid_steps=(1.0,),
        threshold_mode="atr_k",
        atr_lookback=5,
        atr_percentile_split=0.4,
    )

    permissive = BreakoutBiasStrategy(StrategyConfig(atr_k_high=1.0, atr_k_low=0.5, **base_config))
    strict = BreakoutBiasStrategy(StrategyConfig(atr_k_high=2.0, atr_k_low=0.5, **base_config))

    orders_permissive = [o for o in permissive.generate_orders(candles) if o.side == "buy"]
    orders_strict = [o for o in strict.generate_orders(candles) if o.side == "buy"]

    assert len(orders_strict) <= len(orders_permissive)


def test_exit_modes_trigger_and_chandelier_stop_monotonic() -> None:
    atr_config = StrategyConfig(
        breakout_threshold=0.0,
        order_size=0.3,
        pyramid_steps=(1.0,),
        exit_mode="atr_trail",
        atr_trailing_multiplier=0.8,
    )
    atr_strategy = BreakoutBiasStrategy(atr_config)
    atr_candles = [
        _build_ns_candle("SOLUSDT", 0, 50.0, 52.0, high_price=53.0, low_price=49.5),
        _build_ns_candle("SOLUSDT", 1, 52.0, 54.0, high_price=55.0, low_price=51.5),
        _build_ns_candle("SOLUSDT", 2, 54.0, 50.5, high_price=54.5, low_price=49.0),
    ]
    atr_orders = atr_strategy.generate_orders(atr_candles)
    assert any(order.side == "sell" for order in atr_orders)

    chandelier_config = StrategyConfig(
        breakout_threshold=0.0,
        order_size=0.3,
        pyramid_steps=(1.0,),
        exit_mode="chandelier",
        chandelier_lookback=3,
        chandelier_atr_mult=1.0,
    )
    chandelier = BreakoutBiasStrategy(chandelier_config)
    chandelier_candles = [
        _build_ns_candle("ADAUSDT", 0, 10.0, 10.8, high_price=11.0, low_price=9.9),
        _build_ns_candle("ADAUSDT", 1, 10.8, 11.2, high_price=11.4, low_price=10.5),
        _build_ns_candle("ADAUSDT", 2, 11.2, 11.5, high_price=11.8, low_price=11.0),
        _build_ns_candle("ADAUSDT", 3, 11.5, 10.7, high_price=11.6, low_price=10.6),
    ]

    stop_levels: list[float] = []
    aggregated_orders: list = []
    for candle in chandelier_candles:
        aggregated_orders.extend(chandelier.generate_orders([candle]))
        position = chandelier._positions.get("ADAUSDT")  # noqa: SLF001
        if position and position.chandelier_stop is not None:
            stop_levels.append(position.chandelier_stop)

    assert stop_levels == sorted(stop_levels)
    assert any(order.side == "sell" for order in aggregated_orders)


@given(
    moves=st.lists(
        st.floats(min_value=-0.03, max_value=0.08, allow_nan=False, allow_infinity=False),
        min_size=1,
        max_size=6,
    )
)
def test_deterministic_orders_for_identical_streams(moves: list[float]) -> None:
    base_price = 100.0
    candles = []
    price = base_price
    for idx, move in enumerate(moves):
        next_price = max(price * (1 + move), 1e-6)
        high = max(price, next_price) + 0.5
        low = min(price, next_price) - 0.5
        candles.append(_build_ns_candle("XRPUSDT", idx, price, next_price, high, low))
        price = next_price

    config = StrategyConfig(
        breakout_threshold=0.01,
        order_size=0.2,
        pyramid_steps=(1.0, 0.5),
        threshold_mode="percentile",
        threshold_lookback=3,
    )

    strat_a = BreakoutBiasStrategy(config)
    strat_b = BreakoutBiasStrategy(config)

    assert strat_a.generate_orders(candles) == strat_b.generate_orders(candles)
