from __future__ import annotations

from datetime import UTC, datetime, timedelta

from core.events import CandleEvent
from strategy.breakout_bias import BreakoutBiasStrategy, StrategyConfig


def _make_candle(
    symbol: str,
    index: int,
    open_price: float,
    close_price: float,
    high_price: float | None = None,
    low_price: float | None = None,
    start_dt: datetime | None = None,
) -> CandleEvent:
    start = start_dt or (datetime(2024, 1, 1, tzinfo=UTC) + timedelta(minutes=index))
    return CandleEvent(
        symbol=symbol,
        open=open_price,
        high=high_price if high_price is not None else max(open_price, close_price),
        low=low_price if low_price is not None else min(open_price, close_price),
        close=close_price,
        volume=1.0,
        start=start,
        end=start + timedelta(minutes=1),
    )


def test_trend_path_adds_three_layers_for_fixed_and_geometric() -> None:
    candles = [
        _make_candle("BTCUSDT", 0, 100.0, 105.0, high_price=106.0, low_price=99.5),
        _make_candle("BTCUSDT", 1, 105.0, 110.0, high_price=111.0, low_price=104.5),
        _make_candle("BTCUSDT", 2, 110.0, 116.0, high_price=117.0, low_price=109.0),
        _make_candle("BTCUSDT", 3, 116.0, 120.0, high_price=121.0, low_price=115.0),
    ]

    fixed_strategy = BreakoutBiasStrategy(
        StrategyConfig(
            breakout_threshold=0.0,
            order_size=0.2,
            pyramid_steps=(1.0, 0.5, 0.33),
            pyramid_mode="fixed",
            pyramid_dd_reset_pct=1.0,
            pyramid_stagnation_bars=10,
        )
    )
    fixed_orders = [o for o in fixed_strategy.generate_orders(candles) if o.side == "buy"]
    assert len(fixed_orders) == 3

    geometric_strategy = BreakoutBiasStrategy(
        StrategyConfig(
            breakout_threshold=0.0,
            order_size=0.2,
            pyramid_mode="geometric",
            pyramid_max_steps=3,
            pyramid_dd_reset_pct=1.0,
            pyramid_stagnation_bars=10,
        )
    )
    geometric_orders = [o for o in geometric_strategy.generate_orders(candles) if o.side == "buy"]
    assert len(geometric_orders) == 3
    assert geometric_orders[-1].qty < geometric_orders[0].qty


def test_drawdown_reset_limits_total_adds() -> None:
    candles = [
        _make_candle("ETHUSDT", 0, 50.0, 52.5, high_price=53.0, low_price=49.5),
        _make_candle("ETHUSDT", 1, 52.5, 55.0, high_price=55.5, low_price=53.5),
        _make_candle("ETHUSDT", 2, 55.0, 51.0, high_price=55.2, low_price=49.0),
        _make_candle("ETHUSDT", 3, 51.0, 50.5, high_price=51.2, low_price=49.5),
        _make_candle("ETHUSDT", 4, 50.5, 50.6, high_price=51.0, low_price=50.0),
    ]

    strategy = BreakoutBiasStrategy(
        StrategyConfig(
            breakout_threshold=0.0,
            order_size=0.3,
            pyramid_steps=(1.0, 0.6, 0.4),
            pyramid_mode="fixed",
            pyramid_dd_reset_pct=0.03,
            pyramid_stagnation_bars=10,
        )
    )

    orders = [o for o in strategy.generate_orders(candles) if o.side == "buy"]
    assert len(orders) == 2


def test_stagnation_reset_after_specified_bars() -> None:
    candles = [
        _make_candle("SOLUSDT", 0, 30.0, 31.5, high_price=31.8, low_price=29.8),
        _make_candle("SOLUSDT", 1, 31.5, 32.5, high_price=32.8, low_price=31.0),
        _make_candle("SOLUSDT", 2, 32.5, 32.4, high_price=32.6, low_price=32.0),
        _make_candle("SOLUSDT", 3, 32.4, 32.3, high_price=32.5, low_price=31.9),
        _make_candle("SOLUSDT", 4, 32.3, 32.2, high_price=32.4, low_price=31.8),
    ]

    strategy = BreakoutBiasStrategy(
        StrategyConfig(
            breakout_threshold=0.0,
            order_size=0.25,
            pyramid_steps=(1.0, 0.5, 0.33),
            pyramid_mode="fixed",
            pyramid_dd_reset_pct=1.0,
            pyramid_stagnation_bars=2,
        )
    )

    orders = [o for o in strategy.generate_orders(candles) if o.side == "buy"]
    assert len(orders) == 2
    position = strategy._positions.get("SOLUSDT")  # noqa: SLF001 - test helper
    assert position is not None
    assert position.layers == 0


def test_drawdown_threshold_monotonicity() -> None:
    candles = [
        _make_candle("ADAUSDT", 0, 10.0, 10.6, high_price=10.7, low_price=9.9),
        _make_candle("ADAUSDT", 1, 10.6, 11.2, high_price=11.4, low_price=10.5),
        _make_candle("ADAUSDT", 2, 11.2, 10.4, high_price=11.3, low_price=9.8),
        _make_candle("ADAUSDT", 3, 10.4, 10.3, high_price=10.5, low_price=10.0),
        _make_candle("ADAUSDT", 4, 10.3, 10.5, high_price=10.6, low_price=10.1),
    ]

    tight_reset = BreakoutBiasStrategy(
        StrategyConfig(
            breakout_threshold=0.0,
            order_size=0.2,
            pyramid_steps=(1.0, 0.5, 0.25),
            pyramid_mode="fixed",
            pyramid_dd_reset_pct=0.02,
            pyramid_stagnation_bars=10,
        )
    )
    relaxed_reset = BreakoutBiasStrategy(
        StrategyConfig(
            breakout_threshold=0.0,
            order_size=0.2,
            pyramid_steps=(1.0, 0.5, 0.25),
            pyramid_mode="fixed",
            pyramid_dd_reset_pct=0.05,
            pyramid_stagnation_bars=10,
        )
    )

    tight_orders = [o for o in tight_reset.generate_orders(candles) if o.side == "buy"]
    relaxed_orders = [o for o in relaxed_reset.generate_orders(candles) if o.side == "buy"]

    assert len(tight_orders) <= len(relaxed_orders)


def test_session_filter_allows_entries_only_within_window() -> None:
    base = datetime(2024, 1, 1, tzinfo=UTC)
    candles = [
        _make_candle(
            "LINKUSDT",
            0,
            20.0,
            21.0,
            high_price=21.2,
            low_price=19.8,
            start_dt=base.replace(hour=6, minute=30),
        ),
        _make_candle(
            "LINKUSDT",
            1,
            21.0,
            22.5,
            high_price=22.8,
            low_price=20.9,
            start_dt=base.replace(hour=9, minute=0),
        ),
        _make_candle(
            "LINKUSDT",
            2,
            22.5,
            23.5,
            high_price=23.8,
            low_price=22.4,
            start_dt=base.replace(hour=23, minute=10),
        ),
    ]

    strategy = BreakoutBiasStrategy(
        StrategyConfig(
            breakout_threshold=0.0,
            order_size=0.1,
            pyramid_steps=(1.0, 0.5, 0.25),
            pyramid_mode="fixed",
            pyramid_dd_reset_pct=1.0,
            pyramid_stagnation_bars=10,
            enforce_sessions=True,
            trade_sessions=(("07:00", "22:00"),),
        )
    )

    orders = [o for o in strategy.generate_orders(candles) if o.side == "buy"]

    assert len(orders) == 1
    assert orders[0].ts.hour == 9


def test_news_freeze_blocks_entries_but_allows_exit() -> None:
    base = datetime(2024, 1, 1, tzinfo=UTC)
    candles = [
        _make_candle(
            "BNBUSDT",
            0,
            300.0,
            309.0,
            high_price=310.0,
            low_price=299.0,
            start_dt=base.replace(hour=8, minute=0),
        ),
        _make_candle(
            "BNBUSDT",
            1,
            309.0,
            315.0,
            high_price=316.0,
            low_price=300.0,
            start_dt=base.replace(hour=8, minute=15),
        ),
    ]

    strategy = BreakoutBiasStrategy(
        StrategyConfig(
            breakout_threshold=0.0,
            order_size=0.2,
            pyramid_steps=(1.0, 0.5),
            pyramid_mode="fixed",
            pyramid_dd_reset_pct=1.0,
            pyramid_stagnation_bars=10,
            enforce_sessions=True,
            trade_sessions=(("07:00", "22:00"),),
            news_freeze=(("2024-01-01T08:10:00+00:00", "2024-01-01T08:30:00+00:00"),),
            stop_loss_pct=0.02,
        )
    )

    orders = strategy.generate_orders(candles)
    buys = [o for o in orders if o.side == "buy"]
    sells = [o for o in orders if o.side == "sell"]

    assert len(buys) == 1
    assert len(sells) == 1


def test_session_window_crossing_midnight() -> None:
    first_day = datetime(2024, 1, 1, tzinfo=UTC)
    second_day = datetime(2024, 1, 2, tzinfo=UTC)
    candles = [
        _make_candle(
            "DOGEUSDT",
            0,
            0.1,
            0.105,
            high_price=0.106,
            low_price=0.099,
            start_dt=first_day.replace(hour=15, minute=0),
        ),
        _make_candle(
            "DOGEUSDT",
            1,
            0.105,
            0.11,
            high_price=0.112,
            low_price=0.104,
            start_dt=first_day.replace(hour=23, minute=30),
        ),
        _make_candle(
            "DOGEUSDT",
            2,
            0.11,
            0.115,
            high_price=0.117,
            low_price=0.109,
            start_dt=second_day.replace(hour=1, minute=30),
        ),
    ]

    strategy = BreakoutBiasStrategy(
        StrategyConfig(
            breakout_threshold=0.0,
            order_size=0.15,
            pyramid_steps=(1.0, 0.6, 0.3),
            pyramid_mode="fixed",
            pyramid_dd_reset_pct=1.0,
            pyramid_stagnation_bars=10,
            enforce_sessions=True,
            trade_sessions=(("22:00", "02:00"),),
        )
    )

    orders = [o for o in strategy.generate_orders(candles) if o.side == "buy"]

    assert len(orders) == 2
    assert all(order.ts.hour in {23, 1} for order in orders)


def test_weekends_blocked_when_disabled() -> None:
    saturday = datetime(2024, 1, 6, 9, 0, tzinfo=UTC)
    weekend_candles = [
        _make_candle(
            "LTCUSDT",
            0,
            70.0,
            72.5,
            high_price=73.0,
            low_price=69.5,
            start_dt=saturday,
        ),
        _make_candle(
            "LTCUSDT",
            1,
            72.5,
            74.0,
            high_price=74.5,
            low_price=72.0,
            start_dt=saturday + timedelta(minutes=1),
        ),
    ]

    config = StrategyConfig(
        breakout_threshold=0.0,
        order_size=0.2,
        pyramid_steps=(1.0,),
        enforce_sessions=True,
        allow_weekends=False,
        trade_sessions=(("00:00", "23:59"),),
    )

    weekend_strategy = BreakoutBiasStrategy(config)
    weekend_orders = [
        order
        for order in weekend_strategy.generate_orders(weekend_candles)
        if order.side == "buy"
    ]
    assert not weekend_orders

    monday = datetime(2024, 1, 8, 9, 0, tzinfo=UTC)
    weekday_candles = [
        _make_candle(
            "LTCUSDT",
            0,
            80.0,
            82.5,
            high_price=83.0,
            low_price=79.5,
            start_dt=monday,
        )
    ]

    weekday_strategy = BreakoutBiasStrategy(config)
    weekday_orders = [
        order
        for order in weekday_strategy.generate_orders(weekday_candles)
        if order.side == "buy"
    ]

    assert len(weekday_orders) == 1
