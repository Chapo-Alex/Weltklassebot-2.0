from __future__ import annotations

import importlib.util
import pathlib
import sys
from datetime import UTC, datetime, timedelta

import pytest

try:
    from hypothesis import given, strategies as st
except ModuleNotFoundError:  # pragma: no cover - fallback for offline environments
    stub_name = "_hypothesis_stub"
    if stub_name in sys.modules:
        module = sys.modules[stub_name]
    else:
        stub_path = pathlib.Path(__file__).resolve().parents[1] / "_hypothesis_stub.py"
        spec = importlib.util.spec_from_file_location(stub_name, stub_path)
        module = importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        sys.modules[stub_name] = module
        spec.loader.exec_module(module)
    given = module.given
    st = module.strategies

from core.events import CandleEvent
from strategy.breakout_bias import BreakoutBiasStrategy, StrategyConfig


def _build_candle(
    symbol: str,
    start: datetime,
    open_price: float,
    close_price: float,
    high_price: float | None = None,
    low_price: float | None = None,
) -> CandleEvent:
    return CandleEvent(
        symbol=symbol,
        open=open_price,
        high=high_price if high_price is not None else max(open_price, close_price),
        low=low_price if low_price is not None else min(open_price, close_price),
        close=close_price,
        volume=1.0,
        start=start,
        end=start + timedelta(minutes=1),
    )


# Parametrised unit tests for pyramiding, exits, bias weighting and trailing stops.
@pytest.mark.parametrize(
    "pyramid_steps, expected_entries",
    [((1.0,), 1), ((1.0, 0.5), 2), ((1.0, 0.5, 0.25), 3)],
)
def test_breakout_bias_supports_pyramiding(
    pyramid_steps: tuple[float, ...], expected_entries: int
) -> None:
    strategy = BreakoutBiasStrategy(
        StrategyConfig(breakout_threshold=0.01, order_size=0.2, pyramid_steps=pyramid_steps)
    )
    start = datetime(2024, 1, 1, tzinfo=UTC)
    candles = [
        _build_candle(
            "BTCUSDT",
            start + timedelta(minutes=i),
            100.0 + i,
            101.5 + i,
        )
        for i in range(4)
    ]

    orders = [order for order in strategy.generate_orders(candles) if order.side == "buy"]

    assert len(orders) == min(expected_entries, len(candles))


@pytest.mark.parametrize(
    "tp_pct, sl_pct, high_price, low_price",
    [
        (0.02, None, 105.0, 100.0),
        (None, 0.01, 101.0, 98.0),
    ],
    ids=["take-profit", "stop-loss"],
)
def test_breakout_bias_exit_orders(
    tp_pct: float | None,
    sl_pct: float | None,
    high_price: float,
    low_price: float,
) -> None:
    config = StrategyConfig(
        breakout_threshold=0.0,
        order_size=1.0,
        take_profit_pct=tp_pct,
        stop_loss_pct=sl_pct,
        pyramid_steps=(1.0,),
    )
    strategy = BreakoutBiasStrategy(config)
    start = datetime(2024, 1, 1, tzinfo=UTC)
    candles = [
        _build_candle("ETHUSDT", start, 100.0, 102.0, high_price=102.0, low_price=99.0),
        _build_candle(
            "ETHUSDT",
            start + timedelta(minutes=1),
            102.0,
            101.0 if tp_pct is not None else 100.0,
            high_price=high_price,
            low_price=low_price,
        ),
    ]

    orders = strategy.generate_orders(candles)

    assert any(order.side == "sell" for order in orders)


@pytest.mark.parametrize(
    "bias_overrides, expected_qty",
    [({}, 0.5), ({"BTCUSDT": 2.0}, 1.0)],
    ids=["default-bias", "overridden-bias"],
)
def test_breakout_bias_bias_weighting_scales_qty(
    bias_overrides: dict[str, float], expected_qty: float
) -> None:
    config = StrategyConfig(
        breakout_threshold=0.0,
        order_size=0.5,
        bias_overrides=bias_overrides,
    )
    strategy = BreakoutBiasStrategy(config)
    start = datetime(2024, 1, 1, tzinfo=UTC)
    candles = [_build_candle("BTCUSDT", start, 100.0, 102.0)]

    orders = strategy.generate_orders(candles)

    assert orders[0].qty == pytest.approx(expected_qty)


@pytest.mark.parametrize(
    "closing_prices, high_low_pairs, expect_exit",
    [
        ([55.0, 52.0, 48.0], [(56.0, 49.0), (57.0, 50.0), (53.0, 47.0)], True),
        ([55.0, 54.5, 56.0], [(56.0, 54.0), (55.5, 54.3), (56.1, 55.8)], False),
    ],
    ids=["trailing-hit", "no-trailing"],
)
def test_breakout_bias_trailing_exit_behavior(
    closing_prices: list[float], high_low_pairs: list[tuple[float, float]], expect_exit: bool
) -> None:
    config = StrategyConfig(
        breakout_threshold=0.0,
        order_size=0.5,
        atr_trailing_multiplier=1.5,
        pyramid_steps=(1.0, 1.0),
    )
    strategy = BreakoutBiasStrategy(config)
    start = datetime(2024, 1, 1, tzinfo=UTC)
    candles = [
        _build_candle(
            "SOLUSDT",
            start + timedelta(minutes=index),
            50.0 + index,
            closing_prices[index],
            high_price=high_low_pairs[index][0],
            low_price=high_low_pairs[index][1],
        )
        for index in range(len(closing_prices))
    ]

    orders = strategy.generate_orders(candles)

    assert any(order.side == "sell" for order in orders) is expect_exit


@given(
    moves=st.lists(
        st.floats(min_value=-0.05, max_value=0.2, allow_nan=False, allow_infinity=False),
        min_size=1,
        max_size=8,
    )
)
def test_breakout_bias_never_emits_negative_qty(moves: list[float]) -> None:
    strategy = BreakoutBiasStrategy(
        StrategyConfig(breakout_threshold=0.0, order_size=0.3, pyramid_steps=(1.0, 1.0, 1.0))
    )
    start = datetime(2024, 1, 1, tzinfo=UTC)
    price = 100.0
    candles: list[CandleEvent] = []
    for idx, move in enumerate(moves):
        close = price * (1 + move)
        high = max(price, close)
        low = min(price, close)
        candles.append(
            CandleEvent(
                symbol="ADAUSDT",
                open=price,
                high=high,
                low=low,
                close=close,
                volume=1.0,
                start=start + timedelta(minutes=idx),
                end=start + timedelta(minutes=idx + 1),
            )
        )
        price = max(close, 0.1)

    orders = strategy.generate_orders(candles)
    assert all(order.qty >= 0 for order in orders)
