from __future__ import annotations

import importlib.util
import pathlib
import sys
from datetime import UTC, datetime

import pytest

try:
    from hypothesis import given, strategies as st
except ModuleNotFoundError:  # pragma: no cover - fallback for offline environments
    stub_name = "_hypothesis_stub"
    if stub_name in sys.modules:
        module = sys.modules[stub_name]
    else:
        stub_path = pathlib.Path(__file__).resolve().parents[1] / "_hypothesis_stub.py"
        spec = importlib.util.spec_from_file_location(stub_name, stub_path)
        module = importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        sys.modules[stub_name] = module
        spec.loader.exec_module(module)
    given = module.given
    st = module.strategies

from core.events import FillEvent
from portfolio.accounting import fifo_pnl


@given(
    sell_qty=st.floats(min_value=0.01, max_value=1.0, allow_nan=False, allow_infinity=False),
    extra=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
    buy_price=st.floats(
        min_value=10.0,
        max_value=100_000.0,
        allow_nan=False,
        allow_infinity=False,
    ),
    sell_price=st.floats(
        min_value=10.0,
        max_value=100_000.0,
        allow_nan=False,
        allow_infinity=False,
    ),
)
def test_fifo_matches_manual_calculation(
    sell_qty: float, extra: float, buy_price: float, sell_price: float
) -> None:
    buy_qty = sell_qty + extra
    fills = [
        FillEvent(
            order_id="buy",
            ts=datetime(2024, 1, 1, tzinfo=UTC),
            qty=buy_qty,
            price=buy_price,
            fee=0.0,
            liquidity_flag="Taker",
            symbol="BTCUSDT",
            side="buy",
        ),
        FillEvent(
            order_id="sell",
            ts=datetime(2024, 1, 1, tzinfo=UTC),
            qty=sell_qty,
            price=sell_price,
            fee=0.0,
            liquidity_flag="Taker",
            symbol="BTCUSDT",
            side="sell",
        ),
    ]

    expected = (sell_price - buy_price) * sell_qty
    assert fifo_pnl(fills) == pytest.approx(expected)


def test_fifo_raises_when_inventory_negative() -> None:
    fills = [
        FillEvent(
            order_id="buy",
            ts=datetime(2024, 1, 1, tzinfo=UTC),
            qty=0.5,
            price=10_000.0,
            fee=0.0,
            liquidity_flag="Taker",
            symbol="BTCUSDT",
            side="buy",
        ),
        FillEvent(
            order_id="sell",
            ts=datetime(2024, 1, 1, tzinfo=UTC),
            qty=1.0,
            price=11_000.0,
            fee=0.0,
            liquidity_flag="Taker",
            symbol="BTCUSDT",
            side="sell",
        ),
    ]

    with pytest.raises(ValueError):
        fifo_pnl(fills)
