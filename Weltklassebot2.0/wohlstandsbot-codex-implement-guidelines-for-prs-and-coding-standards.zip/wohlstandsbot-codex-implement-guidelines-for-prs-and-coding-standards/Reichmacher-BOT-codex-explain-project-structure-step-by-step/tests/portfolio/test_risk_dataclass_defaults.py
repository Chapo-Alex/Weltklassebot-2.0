from __future__ import annotations

import importlib
import importlib.util
import pathlib
import sys
import types
from datetime import UTC, datetime

import pytest

try:
    from hypothesis import given, strategies as st
except ModuleNotFoundError:  # pragma: no cover - fallback for offline environments
    stub_name = "_hypothesis_stub"
    if stub_name in sys.modules:
        module = sys.modules[stub_name]
    else:
        stub_path = pathlib.Path(__file__).resolve().parents[1] / "_hypothesis_stub.py"
        spec = importlib.util.spec_from_file_location(stub_name, stub_path)
        module = importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        sys.modules[stub_name] = module
        spec.loader.exec_module(module)
    given = module.given
    st = module.strategies

from types import SimpleNamespace

from core.events import FillEvent, OrderEvent


@pytest.fixture(autouse=True)
def _ensure_fake_pydantic(monkeypatch: pytest.MonkeyPatch) -> None:
    """Provide a lightweight pydantic stub for environments without the dependency."""

    fake_pydantic = types.ModuleType("pydantic")

    class _BaseModel:
        def __init__(self, **data):
            for key, value in data.items():
                setattr(self, key, value)

    fake_pydantic.BaseModel = _BaseModel  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "pydantic", fake_pydantic)
    monkeypatch.setitem(sys.modules, "pydantic.main", fake_pydantic)
    monkeypatch.delitem(sys.modules, "portfolio.risk", raising=False)


def _build_manager(**overrides):
    risk = importlib.import_module("portfolio.risk")
    params_kwargs = {
        "max_daily_dd_pct": 5.0,
        "cooldown_after_loss_s": 60.0,
        "max_positions": 2,
        "max_exposure_notional": 10_000.0,
        "min_atr_pct": 0.001,
    }
    params_kwargs.update(overrides)
    params = risk.RiskParameters(**params_kwargs)
    return risk, risk.RiskManagerV2(params)


def test_risk_manager_defaults_allow_order() -> None:
    risk, manager = _build_manager()

    assert manager.state is risk.RiskState.RUNNING

    decision = manager.assess_new_order(
        OrderEvent(
            id="test-order",
            symbol="BTCUSDT",
            side="buy",
            type="market",
            qty=0.1,
            status="NEW",
            ts=datetime(2024, 1, 1, tzinfo=UTC),
            price=25_000.0,
        ),
        context=None,
    )

    assert decision.allow
    assert decision.reason == "no context provided"


@given(
    qty=st.floats(min_value=0.0, max_value=2.0, allow_nan=False, allow_infinity=False),
    price=st.floats(min_value=1.0, max_value=50_000.0, allow_nan=False, allow_infinity=False),
    notional=st.floats(min_value=0.0, max_value=9_000.0, allow_nan=False, allow_infinity=False),
)
def test_risk_manager_exposure_gate_matches_projection(
    qty: float, price: float, notional: float
) -> None:
    risk, manager = _build_manager()

    context = risk.RiskContext(
        open_positions={},
        notional_sum=notional,
        atr_pct_by_symbol={"BTCUSDT": 0.01},
        leverage=1.0,
    )
    order = OrderEvent(
        id="property-order",
        symbol="BTCUSDT",
        side="buy",
        type="market",
        qty=qty,
        status="NEW",
        ts=datetime(2024, 1, 1, tzinfo=UTC),
        price=price,
    )

    decision = manager.assess_new_order(order, context)
    projected = notional + qty * price

    assert (projected <= manager.params.max_exposure_notional and decision.allow) or (
        projected > manager.params.max_exposure_notional and not decision.allow
    )

def test_health_snapshot_reports_state() -> None:
    _, manager = _build_manager()
    snapshot = manager.health_snapshot()

    assert snapshot["state"] == "RUNNING"
    assert snapshot["equity"] == 0.0


def test_risk_manager_drawdown_and_reset_cycle() -> None:
    risk, manager = _build_manager()
    manager.set_equity(10_000.0)
    manager.set_equity(9_000.0)

    assert manager.state is risk.RiskState.HALTED

    manager.reset_day_if_needed(datetime(2024, 1, 2, tzinfo=UTC))

    assert manager.state is risk.RiskState.RUNNING
    assert manager.health_snapshot()["day_high"] == pytest.approx(9_000.0)


def test_risk_manager_cooldown_and_tick_flow() -> None:
    risk, manager = _build_manager()

    manager.on_pnl(-100.0)
    assert manager.state is risk.RiskState.COOLDOWN

    manager.tick(manager.params.cooldown_after_loss_s - 1)
    assert manager.state is risk.RiskState.COOLDOWN

    manager.tick(manager.params.cooldown_after_loss_s)
    assert manager.state is risk.RiskState.RUNNING


def test_risk_manager_update_after_fill_triggers_cooldown() -> None:
    risk, manager = _build_manager()

    fill = FillEvent(
        order_id="fill-1",
        ts=datetime(2024, 1, 1, tzinfo=UTC),
        qty=0.1,
        price=20_000.0,
        fee=0.0,
        liquidity_flag="Taker",
        symbol="BTCUSDT",
        side="sell",
    )
    fill_with_pnl = SimpleNamespace(**fill.__dict__, pnl=-50.0)
    manager.update_after_fill(fill_with_pnl)

    assert manager.state is risk.RiskState.COOLDOWN


def test_risk_manager_force_state_overrides() -> None:
    risk, manager = _build_manager()
    manager.force_state(risk.RiskState.HALTED, "ops override")

    assert manager.state is risk.RiskState.HALTED

    manager.force_state(risk.RiskState.RUNNING, "ops resume")

    assert manager.state is risk.RiskState.RUNNING


def test_risk_manager_denials_cover_all_gates() -> None:
    risk, manager = _build_manager(max_positions=1)
    context = risk.RiskContext(
        open_positions={"BTC": object(), "ETH": object()},
        notional_sum=1_000.0,
        atr_pct_by_symbol={"BTCUSDT": 0.0001},
        leverage=1.0,
    )
    order = OrderEvent(
        id="denial-order",
        symbol="BTCUSDT",
        side="buy",
        type="market",
        qty=1.0,
        status="NEW",
        ts=datetime(2024, 1, 1, tzinfo=UTC),
        price=25_000.0,
    )

    decision = manager.assess_new_order(order, context)
    assert not decision.allow
    assert decision.reason == "max positions reached"

    risk, manager = _build_manager(min_atr_pct=0.005)
    context = risk.RiskContext(
        open_positions={},
        notional_sum=1_000.0,
        atr_pct_by_symbol={"BTCUSDT": 0.0001},
        leverage=1.0,
    )
    decision = manager.assess_new_order(order, context)
    assert not decision.allow
    assert decision.reason == "atr filter active"

    risk, manager = _build_manager()
    context = risk.RiskContext(
        open_positions={},
        notional_sum=manager.params.max_exposure_notional - 100.0,
        atr_pct_by_symbol={"BTCUSDT": 0.02},
        leverage=2.0,
    )
    decision = manager.assess_new_order(order, context)
    assert not decision.allow
    assert decision.reason == "exposure limit exceeded"

    price_less = OrderEvent(
        id="no-price",
        symbol="BTCUSDT",
        side="buy",
        type="market",
        qty=1.0,
        status="NEW",
        ts=datetime(2024, 1, 1, tzinfo=UTC),
        price=None,
    )
    decision = manager.assess_new_order(price_less, context)
    assert not decision.allow
    assert decision.reason == "price required for exposure check"
