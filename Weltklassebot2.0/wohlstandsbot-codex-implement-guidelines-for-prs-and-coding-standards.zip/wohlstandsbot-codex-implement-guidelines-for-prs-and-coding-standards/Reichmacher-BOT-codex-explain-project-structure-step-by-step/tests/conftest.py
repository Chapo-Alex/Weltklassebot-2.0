from __future__ import annotations

import ast
import sys
import threading
from collections import defaultdict
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

import pytest

try:  # Python 3.11+
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - fallback for <3.11 interpreters
    import tomli as tomllib  # type: ignore[no-redef]


@dataclass(slots=True)
class _CoverageTarget:
    label: str
    path: Path

    def iter_files(self) -> Iterable[Path]:
        if self.path.is_file():
            yield self.path
            return
        yield from self.path.rglob("*.py")

    def matches(self, filename: Path) -> bool:
        if self.path.is_file():
            return filename == self.path
        try:
            return filename.is_relative_to(self.path)
        except ValueError:  # pragma: no cover - older Python fallback
            return str(filename).startswith(str(self.path))


class _CoverageTracer:
    def __init__(self, targets: list[_CoverageTarget], threshold: float) -> None:
        self._targets = targets
        self._threshold = threshold
        self._executed: dict[Path, set[int]] = defaultdict(set)
        self._tracing = False

    @staticmethod
    def _statement_lines(path: Path) -> set[int]:
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source)
        lines: set[int] = set()
        for node in ast.walk(tree):
            lineno = getattr(node, "lineno", None)
            if lineno is not None:
                lines.add(int(lineno))
        return lines

    def _trace(self, frame, event, arg):  # type: ignore[no-untyped-def]
        if event != "line":
            return self._trace
        filename = Path(frame.f_code.co_filename).resolve()
        for target in self._targets:
            if target.matches(filename):
                self._executed[filename].add(frame.f_lineno)
                break
        return self._trace

    def start(self) -> None:
        if self._tracing:
            return
        self._tracing = True
        sys.settrace(self._trace)
        threading.settrace(self._trace)

    def stop(self) -> None:
        if not self._tracing:
            return
        sys.settrace(None)
        threading.settrace(None)
        self._tracing = False

    def report(self) -> tuple[dict[str, float], float]:
        results: dict[str, float] = {}
        for target in self._targets:
            total = 0
            covered = 0
            for file in target.iter_files():
                statements = self._statement_lines(file)
                total += len(statements)
                executed = self._executed.get(file.resolve(), set())
                covered += len(statements & executed)
            ratio = 1.0 if total == 0 else covered / total
            results[target.label] = ratio
        return results, self._threshold


def _load_targets(config: pytest.Config) -> tuple[list[_CoverageTarget], float]:
    project_root = Path(__file__).resolve().parents[1]
    pyproject = project_root / "pyproject.toml"
    threshold = 0.85
    target_paths = [
        "src/core",
        "src/portfolio",
        "src/portfolio/risk.py",
        "src/strategy",
    ]
    if pyproject.exists():
        data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
        reichmacher = data.get("tool", {}).get("reichmacher", {})
        threshold = float(reichmacher.get("coverage_threshold", threshold))
        target_paths = reichmacher.get("coverage_targets", target_paths)
    targets = []
    for raw_path in target_paths:
        path = (project_root / raw_path).resolve()
        raw = Path(raw_path)
        label = raw.stem if raw.suffix else raw.name
        targets.append(_CoverageTarget(label=label, path=path))
    return targets, threshold


def pytest_configure(config: pytest.Config) -> None:
    targets, threshold = _load_targets(config)
    tracer = _CoverageTracer(targets, threshold)
    tracer.start()
    config._coverage_tracer = tracer  # type: ignore[attr-defined]


def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:  # type: ignore[override]
    tracer: _CoverageTracer | None = getattr(session.config, "_coverage_tracer", None)
    if tracer is None:
        return
    tracer.stop()
    results, threshold = tracer.report()
    session.config._coverage_results = results  # type: ignore[attr-defined]
    failing = [label for label, ratio in results.items() if ratio < threshold]
    if failing:
        session.config._coverage_failed = failing  # type: ignore[attr-defined]
        session.exitstatus = pytest.ExitCode.TESTS_FAILED


def pytest_terminal_summary(terminalreporter, exitstatus):  # type: ignore[no-untyped-def]
    tracer: _CoverageTracer | None = getattr(terminalreporter.config, "_coverage_tracer", None)
    if tracer is None:
        return
    results: dict[str, float] = getattr(terminalreporter.config, "_coverage_results", {})
    threshold = tracer._threshold
    terminalreporter.write_sep("-", f"coverage summary (threshold {threshold * 100:.0f}%)")
    for label, ratio in sorted(results.items()):
        terminalreporter.write_line(f"{label:>10}: {ratio * 100:5.1f}%")
    failing = getattr(terminalreporter.config, "_coverage_failed", [])
    if failing:
        terminalreporter.write_line(
            f"Coverage below threshold for: {', '.join(failing)}",
            yellow=True,
        )
