"""Risk management state machine with Prometheus instrumentation."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import date, datetime
from enum import Enum
from typing import Final

try:  # pragma: no cover - optional dependency for offline test environments
    from prometheus_client import CollectorRegistry, Counter, Gauge
except ModuleNotFoundError:  # pragma: no cover
    from ._prometheus_stub import CollectorRegistry, Counter, Gauge
from pydantic import BaseModel

from core.events import FillEvent, OrderEvent


class RiskState(str, Enum):
    """Represents the lifecycle of trading permissions."""

    RUNNING = "RUNNING"
    COOLDOWN = "COOLDOWN"
    HALTED = "HALTED"


@dataclass(slots=True)
class RiskMetrics:
    """Holder for Prometheus metric instruments used by :class:`RiskManagerV2`."""

    state: Gauge
    denials: Counter
    projected_exposure: Gauge
    equity: Gauge
    drawdown: Gauge

    @classmethod
    def from_registry(cls, registry: CollectorRegistry | None) -> RiskMetrics:
        """Build metrics either on the default registry or on the provided one."""

        kwargs = {"registry": registry} if registry is not None else {}
        return cls(
            state=Gauge(
                "risk_manager_state",
                "Indicator of the current risk state (RUNNING, COOLDOWN, HALTED).",
                labelnames=("state",),
                **kwargs,
            ),
            denials=Counter(
                "risk_gate_denied_total",
                "Total number of orders rejected by risk gates.",
                labelnames=("reason",),
                **kwargs,
            ),
            projected_exposure=Gauge(
                "risk_projected_exposure_notional",
                "Projected notional exposure after evaluating the latest order.",
                **kwargs,
            ),
            equity=Gauge(
                "risk_equity_last",
                "Latest equity observed by the risk manager.",
                **kwargs,
            ),
            drawdown=Gauge(
                "risk_drawdown_pct",
                "Current drawdown percentage within the active trading day.",
                **kwargs,
            ),
        )


DEFAULT_METRICS: Final = RiskMetrics.from_registry(None)


class Decision(BaseModel):
    """Outcome of a risk assessment."""

    allow: bool
    reason: str


@dataclass(frozen=True)
class RiskParameters:
    """Container for configurable risk limits."""

    max_daily_dd_pct: float
    cooldown_after_loss_s: float
    max_positions: int
    max_exposure_notional: float
    min_atr_pct: float


@dataclass(frozen=True)
class RiskContext:
    """Snapshot of portfolio state relevant for risk checks."""

    open_positions: Mapping[str, object]
    notional_sum: float
    atr_pct_by_symbol: Mapping[str, float]
    leverage: float = 1.0


@dataclass
class RiskManagerV2:
    """Finite state machine that enforces the configured risk limits."""

    params: RiskParameters
    registry: CollectorRegistry | None = None
    _state: RiskState = field(init=False, default=RiskState.RUNNING)
    _day_high: float = field(init=False, default=0.0)
    _equity: float = field(init=False, default=0.0)
    _day_marker: date | None = field(init=False, default=None)
    _cooldown_until: float | None = field(init=False, default=None)
    _now_ts: float = field(init=False, default=0.0)
    _logger_name: str = field(init=False, default="risk")

    def __post_init__(self) -> None:
        if self.registry is None:
            self._metrics = DEFAULT_METRICS
        else:
            self._metrics = RiskMetrics.from_registry(self.registry)
        self._update_state_metric(self._state)

    @property
    def state(self) -> RiskState:
        """Return the current risk state."""

        return self._state

    def set_equity(self, equity: float) -> None:
        """Record the latest equity value and update drawdown tracking."""

        self._equity = equity
        if equity > self._day_high:
            self._day_high = equity
        self._metrics.equity.set(self._equity)
        self._evaluate_drawdown()

    def on_pnl(self, pnl: float) -> None:
        """Apply cooldown after realised losses from aggregated PnL updates."""

        if pnl < 0:
            self._enter_cooldown("loss realised on pnl callback")

    def tick(self, now_ts: float) -> None:
        """Advance the internal clock and lift cooldowns when expired."""

        self._now_ts = now_ts
        if self._state == RiskState.COOLDOWN and self._cooldown_until is not None:
            if now_ts >= self._cooldown_until:
                self._cooldown_until = None
                self._transition(RiskState.RUNNING, "cooldown expired")

    def assess_new_order(self, order: OrderEvent, context: RiskContext | None) -> Decision:
        """Check whether a new order complies with the configured risk gates."""

        if self._state == RiskState.HALTED:
            return self._deny("halted due to drawdown")
        if self._state == RiskState.COOLDOWN:
            return self._deny("cooldown in effect")

        if context is None:
            return Decision(allow=True, reason="no context provided")

        if (
            self.params.max_positions > 0
            and len(context.open_positions) >= self.params.max_positions
        ):
            return self._deny("max positions reached")

        symbol_atr_pct = context.atr_pct_by_symbol.get(order.symbol)
        if (
            self.params.min_atr_pct > 0
            and symbol_atr_pct is not None
            and symbol_atr_pct < self.params.min_atr_pct
        ):
            return self._deny("atr filter active")

        projected = context.notional_sum
        if self.params.max_exposure_notional > 0:
            price = order.price
            if price is None:
                return self._deny("price required for exposure check")
            leverage = context.leverage if context.leverage > 0 else 1.0
            projected = context.notional_sum + abs(order.qty) * price * leverage
            if projected > self.params.max_exposure_notional:
                self._metrics.projected_exposure.set(projected)
                return self._deny("exposure limit exceeded")

        self._metrics.projected_exposure.set(projected)
        return Decision(allow=True, reason="within limits")

    def update_after_fill(self, fill: FillEvent) -> None:
        """Update cooldown status after a fill is processed."""

        pnl = getattr(fill, "pnl", 0.0)
        if pnl < 0:
            self._enter_cooldown("loss realised on fill")

    def reset_day_if_needed(self, now_utc: datetime) -> None:
        """Reset daily markers when a new UTC day begins."""

        current_day = now_utc.date()
        if self._day_marker is None or self._day_marker != current_day:
            self._day_marker = current_day
            self._day_high = self._equity
            self._cooldown_until = None
            if self._state != RiskState.RUNNING:
                self._transition(RiskState.RUNNING, "new trading day")

    def force_state(self, state: RiskState, reason: str) -> None:
        """Externally enforce a risk state transition."""

        if state == RiskState.RUNNING:
            self._cooldown_until = None
        self._transition(state, reason)

    def health_snapshot(self) -> dict[str, float | str | None]:
        """Return a structured health snapshot for monitoring endpoints."""

        return {
            "state": self._state.value,
            "cooldown_until": self._cooldown_until,
            "equity": self._equity,
            "day_high": self._day_high,
        }

    def _evaluate_drawdown(self) -> float:
        if self.params.max_daily_dd_pct <= 0 or self._day_high <= 0:
            self._metrics.drawdown.set(0.0)
            return 0.0
        drawdown = self._day_high - self._equity
        drawdown_pct = (drawdown / self._day_high) * 100
        self._metrics.drawdown.set(drawdown_pct)
        if drawdown_pct >= self.params.max_daily_dd_pct:
            self._transition(RiskState.HALTED, f"drawdown {drawdown_pct:.2f}%")
        return drawdown_pct

    def _enter_cooldown(self, reason: str) -> None:
        if self.params.cooldown_after_loss_s <= 0:
            return
        self._cooldown_until = self._now_ts + self.params.cooldown_after_loss_s
        if self._state not in (RiskState.COOLDOWN, RiskState.HALTED):
            self._transition(RiskState.COOLDOWN, reason)

    def _transition(self, new_state: RiskState, reason: str) -> None:
        if new_state == self._state:
            return
        self._log_state_change(new_state, reason)
        self._state = new_state
        self._update_state_metric(new_state)

    def _update_state_metric(self, state: RiskState) -> None:
        for candidate in RiskState:
            value = 1.0 if candidate is state else 0.0
            self._metrics.state.labels(state=candidate.value).set(value)

    def _deny(self, reason: str) -> Decision:
        self._metrics.denials.labels(reason=reason).inc()
        return Decision(allow=False, reason=reason)

    def _log_state_change(self, new_state: RiskState, reason: str) -> None:
        import logging

        logger = logging.getLogger(self._logger_name)
        level = logging.INFO if new_state == RiskState.RUNNING else logging.WARNING
        logger.log(
            level,
            "risk state transition",
            extra={"state": new_state.value, "reason": reason},
        )


# Backwards compatibility export
RiskManager = RiskManagerV2
__all__ = [
    "Decision",
    "RiskContext",
    "RiskManager",
    "RiskManagerV2",
    "RiskParameters",
    "RiskState",
]
