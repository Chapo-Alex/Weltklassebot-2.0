"""Utility helpers for portfolio accounting and PnL validation."""

from __future__ import annotations

from collections import deque
from collections.abc import Iterable

from core.events import FillEvent


def fifo_pnl(fills: Iterable[FillEvent]) -> float:
    """Compute realised PnL using FIFO matching for the provided fills."""

    queue: deque[tuple[float, float]] = deque()
    pnl = 0.0
    for fill in fills:
        if fill.qty < 0:
            msg = "Fill quantity must be non-negative"
            raise ValueError(msg)
        if fill.side not in {"buy", "sell"}:
            msg = "Fill side must be 'buy' or 'sell'"
            raise ValueError(msg)
        if fill.side == "buy":
            queue.append((fill.qty, fill.price))
            continue
        qty_to_match = fill.qty
        while qty_to_match > 0 and queue:
            open_qty, open_price = queue.popleft()
            trade_qty = min(open_qty, qty_to_match)
            pnl += (fill.price - open_price) * trade_qty
            remaining = open_qty - trade_qty
            qty_to_match -= trade_qty
            if remaining > 0:
                queue.appendleft((remaining, open_price))
        if qty_to_match > 0:
            msg = "Cannot match sell fill without existing inventory"
            raise ValueError(msg)
    return pnl


__all__ = ["fifo_pnl"]
