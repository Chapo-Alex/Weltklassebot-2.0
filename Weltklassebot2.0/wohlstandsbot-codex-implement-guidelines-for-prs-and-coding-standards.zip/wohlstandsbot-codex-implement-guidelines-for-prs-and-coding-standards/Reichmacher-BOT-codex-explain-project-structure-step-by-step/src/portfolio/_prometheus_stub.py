"""Minimal Prometheus client stub for offline test environments."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class CollectorRegistry:
    """Placeholder registry mirroring the interface of prometheus_client."""

    def register(self, metric: Any) -> None:  # pragma: no cover - compatibility method
        del metric


class _Metric:
    def __init__(self, *args: Any, **kwargs: Any) -> None:  # pragma: no cover - stub usage
        del args
        del kwargs
        self._value = 0.0

    def labels(self, **kwargs: Any) -> _Metric:
        del kwargs
        return self

    def inc(self, amount: float = 1.0) -> None:
        self._value += amount

    def set(self, value: float) -> None:
        self._value = value


class Counter(_Metric):
    """Stubbed counter metric."""


class Gauge(_Metric):
    """Stubbed gauge metric."""


__all__ = ["CollectorRegistry", "Counter", "Gauge"]
