"""Event primitives shared across the trading system."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Literal


@dataclass(frozen=True)
class MarketEvent:
    """Represents a trade tick received from an exchange."""

    symbol: str
    price: float
    quantity: float
    ts: datetime


@dataclass(frozen=True)
class CandleEvent:
    """Aggregated candle built from trade data."""

    symbol: str
    open: float
    high: float
    low: float
    close: float
    volume: float
    start: datetime
    end: datetime


OrderSide = Literal["buy", "sell"]
OrderType = Literal["market", "limit"]
OrderStatus = Literal["NEW", "PARTIAL", "FILLED", "CANCELLED"]
LiquidityFlag = Literal["Taker", "Maker"]


@dataclass(frozen=True)
class OrderEvent:
    """State transition for an order lifecycle."""

    id: str
    symbol: str
    side: OrderSide
    type: OrderType
    qty: float
    status: OrderStatus
    ts: datetime
    price: float | None = None


@dataclass(frozen=True)
class FillEvent:
    """Fill received after submitting an order."""

    order_id: str
    ts: datetime
    qty: float
    price: float
    fee: float
    liquidity_flag: LiquidityFlag
    symbol: str | None = None
    side: OrderSide | None = None

