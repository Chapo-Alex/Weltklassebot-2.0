"""Breakout plus bias strategy with pyramiding and risk-aware exits."""

from __future__ import annotations

from collections import deque
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from datetime import UTC, datetime, time
from typing import Literal

from core.events import CandleEvent, OrderEvent

ThresholdMode = Literal["fixed", "percentile", "atr_k"]
ExitMode = Literal["atr_trail", "chandelier"]
PyramidMode = Literal["fixed", "geometric"]

try:  # pragma: no cover - exercised in integration tests
    from prometheus_client import Counter
except ModuleNotFoundError:  # pragma: no cover - offline fallback
    from portfolio._prometheus_stub import Counter

PYRAMID_ADDS = Counter(
    "pyramid_adds_total",
    "Number of pyramiding adds emitted",
    labelnames=("symbol",),
)
PYRAMID_RESETS = Counter(
    "pyramid_resets_total",
    "Number of pyramiding resets triggered",
    labelnames=("symbol", "reason"),
)
ENTRIES_SKIPPED = Counter(
    "entries_skipped_total",
    "Number of potential entries skipped by session or news filters",
    labelnames=("symbol", "reason"),
)


@dataclass(frozen=True, slots=True)
class StrategyConfig:
    """Configuration for the breakout bias strategy."""

    breakout_threshold: float = 0.01
    order_size: float = 0.1
    pyramid_steps: tuple[float, ...] = (1.0,)
    pyramid_mode: PyramidMode = "fixed"
    pyramid_max_steps: int | None = None
    pyramid_dd_reset_pct: float = 0.03
    pyramid_stagnation_bars: int = 5
    enforce_sessions: bool = False
    trade_sessions: tuple[tuple[str, str], ...] = (("07:00", "22:00"),)
    news_freeze: tuple[tuple[str, str], ...] = ()
    allow_weekends: bool = True
    take_profit_pct: float | None = None
    stop_loss_pct: float | None = None
    bias_overrides: Mapping[str, float] = field(default_factory=dict)
    atr_trailing_multiplier: float | None = None
    threshold_mode: ThresholdMode = "fixed"
    threshold_lookback: int = 20
    threshold_percentile: float = 0.75
    atr_lookback: int = 14
    atr_k_low: float = 1.0
    atr_k_high: float = 1.5
    atr_percentile_split: float = 0.5
    exit_mode: ExitMode = "atr_trail"
    chandelier_lookback: int = 22
    chandelier_atr_mult: float = 3.0


@dataclass(slots=True)
class _PositionState:
    """State tracking helper to manage pyramiding layers and exits."""

    layers: int = 0
    qty: float = 0.0
    average_price: float = 0.0
    high_water_mark: float = 0.0
    chandelier_stop: float | None = None
    entry_peak_price: float = 0.0
    stagnation_bars: int = 0
    adds_blocked: bool = False

    def register_fill(self, qty: float, price: float) -> None:
        """Update the position with a newly emitted entry order."""

        total_qty = self.qty + qty
        if total_qty <= 0:
            self.layers = 0
            self.qty = 0.0
            self.average_price = 0.0
            self.high_water_mark = 0.0
            return
        if self.qty:
            numerator = (self.average_price * self.qty) + price * qty
            self.average_price = numerator / total_qty
        else:
            self.average_price = price
        self.qty = total_qty
        self.layers += 1
        self.high_water_mark = max(self.high_water_mark, price)
        self.entry_peak_price = max(self.entry_peak_price, price)
        self.stagnation_bars = 0
        self.adds_blocked = False

    def flatten(self) -> float:
        """Reset the position and return the quantity that needs to be closed."""

        qty = self.qty
        self.layers = 0
        self.qty = 0.0
        self.average_price = 0.0
        self.high_water_mark = 0.0
        self.chandelier_stop = None
        self.entry_peak_price = 0.0
        self.stagnation_bars = 0
        self.adds_blocked = False
        return qty


class BreakoutBiasStrategy:
    """Generate market orders when price breaks above the configured threshold."""

    def __init__(self, config: StrategyConfig | None = None) -> None:
        self._config = config or StrategyConfig()
        self._validate_config()
        self._pyramid_steps = self._build_pyramid_steps()
        self._session_windows = self._build_session_windows()
        self._news_windows = self._build_news_windows()
        self._positions: dict[str, _PositionState] = {}
        self._history: dict[str, deque[CandleEvent]] = {}
        self._history_capacity = max(
            1,
            self._config.threshold_lookback,
            self._config.atr_lookback,
            self._config.chandelier_lookback,
        )

    @property
    def config(self) -> StrategyConfig:
        """Return the immutable configuration."""

        return self._config

    def generate_orders(self, candles: Sequence[CandleEvent]) -> list[OrderEvent]:
        """Create deterministic orders for candles breaching the breakout threshold."""

        orders: list[OrderEvent] = []
        for index, candle in enumerate(candles):
            position = self._positions.setdefault(candle.symbol, _PositionState())
            history = self._history.setdefault(candle.symbol, deque(maxlen=self._history_capacity))
            threshold = self._compute_breakout_threshold(candle, history)
            move = 0.0
            if candle.open > 0:
                move = (candle.close - candle.open) / candle.open
            bias_weight = self._config.bias_overrides.get(candle.symbol, 1.0)
            self._update_pyramiding_state(candle, position)
            skip_reason: str | None = None
            if self._config.enforce_sessions:
                if (not self._config.allow_weekends) and not self._is_weekday(candle.end):
                    skip_reason = "session"
                elif not self._is_within_trade_session(candle.end):
                    skip_reason = "session"
            if skip_reason is None and self._is_within_news_freeze(candle.end):
                skip_reason = "news"

            attempt_entry = move >= threshold and position.layers < len(self._pyramid_steps)

            if attempt_entry:
                if skip_reason is not None:
                    ENTRIES_SKIPPED.labels(symbol=candle.symbol, reason=skip_reason).inc()
                elif not position.adds_blocked:
                    multiplier = self._pyramid_steps[position.layers]
                    qty = round(self._config.order_size * multiplier * bias_weight, 6)
                    if qty > 0:
                        orders.append(
                            OrderEvent(
                                id=f"breakout-{candle.symbol}-{index}-layer{position.layers + 1}",
                                symbol=candle.symbol,
                                side="buy",
                                type="market",
                                qty=qty,
                                status="NEW",
                                ts=candle.end,
                                price=candle.close,
                            )
                        )
                        position.register_fill(qty=qty, price=candle.close)
                        PYRAMID_ADDS.labels(symbol=candle.symbol).inc()

            combined_history = list(history) + [candle]
            exit_qty = self._check_exit_conditions(candle, position, combined_history)
            if exit_qty > 0:
                orders.append(
                    OrderEvent(
                        id=f"exit-{candle.symbol}-{index}",
                        symbol=candle.symbol,
                        side="sell",
                        type="market",
                        qty=round(exit_qty, 6),
                        status="NEW",
                        ts=candle.end,
                        price=candle.close,
                    )
                )
            history.append(candle)
        return orders

    def _validate_config(self) -> None:
        config = self._config
        object.__setattr__(
            config,
            "threshold_percentile",
            min(max(config.threshold_percentile, 0.0), 1.0),
        )
        object.__setattr__(
            config,
            "atr_percentile_split",
            min(max(config.atr_percentile_split, 0.0), 1.0),
        )
        for name in ("threshold_lookback", "atr_lookback", "chandelier_lookback"):
            value = max(getattr(config, name), 1)
            object.__setattr__(config, name, value)
        stagnation = max(config.pyramid_stagnation_bars, 0)
        object.__setattr__(config, "pyramid_stagnation_bars", stagnation)
        object.__setattr__(
            config, "pyramid_dd_reset_pct", max(config.pyramid_dd_reset_pct, 0.0)
        )
        if config.pyramid_max_steps is not None:
            clamped = max(1, min(config.pyramid_max_steps, 8))
            object.__setattr__(config, "pyramid_max_steps", clamped)
        sessions: list[tuple[str, str]] = []
        for start, end in config.trade_sessions:
            sessions.append((str(start).strip(), str(end).strip()))
        object.__setattr__(config, "trade_sessions", tuple(sessions))
        freezes: list[tuple[str, str]] = []
        for start, end in config.news_freeze:
            freezes.append((str(start).strip(), str(end).strip()))
        object.__setattr__(config, "news_freeze", tuple(freezes))
        object.__setattr__(config, "allow_weekends", bool(config.allow_weekends))

    def _build_pyramid_steps(self) -> tuple[float, ...]:
        if self._config.pyramid_mode == "fixed":
            return tuple(
                step for step in self._config.pyramid_steps if step > 0
            ) or (1.0,)
        limit = self._config.pyramid_max_steps or 8
        limit = max(1, min(limit, 8))
        steps = [1.0 / (index + 1) for index in range(limit)]
        return tuple(steps)

    def _build_session_windows(self) -> tuple[tuple[time, time, bool], ...]:
        if not self._config.trade_sessions:
            return ()
        windows: list[tuple[time, time, bool]] = []
        for start_raw, end_raw in self._config.trade_sessions:
            start_time = self._parse_time(start_raw)
            end_time = self._parse_time(end_raw)
            crosses_midnight = start_time >= end_time
            windows.append((start_time, end_time, crosses_midnight))
        return tuple(windows)

    def _build_news_windows(self) -> tuple[tuple[datetime, datetime], ...]:
        if not self._config.news_freeze:
            return ()
        windows: list[tuple[datetime, datetime]] = []
        for start_raw, end_raw in self._config.news_freeze:
            start = self._parse_utc_datetime(start_raw)
            end = self._parse_utc_datetime(end_raw)
            if end < start:
                start, end = end, start
            windows.append((start, end))
        return tuple(windows)

    def _is_within_trade_session(self, ts: datetime) -> bool:
        if not self._session_windows:
            return True
        current_time = ts.astimezone(UTC).time()
        for start, end, crosses_midnight in self._session_windows:
            if crosses_midnight:
                if current_time >= start or current_time < end:
                    return True
            else:
                if start <= current_time < end:
                    return True
        return False

    @staticmethod
    def _is_weekday(ts: datetime) -> bool:
        return ts.astimezone(UTC).weekday() < 5

    def _is_within_news_freeze(self, ts: datetime) -> bool:
        if not self._news_windows:
            return False
        current = ts.astimezone(UTC)
        return any(start <= current <= end for start, end in self._news_windows)

    @staticmethod
    def _parse_time(value: str) -> time:
        try:
            return time.fromisoformat(value)
        except ValueError as exc:  # pragma: no cover - invalid configuration
            raise ValueError(f"invalid time format: {value!r}") from exc

    @staticmethod
    def _parse_utc_datetime(value: str) -> datetime:
        try:
            parsed = datetime.fromisoformat(value)
        except ValueError as exc:  # pragma: no cover - invalid configuration
            raise ValueError(f"invalid datetime format: {value!r}") from exc
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=UTC)
        return parsed.astimezone(UTC)

    def _check_exit_conditions(
        self,
        candle: CandleEvent,
        position: _PositionState,
        history: Sequence[CandleEvent],
    ) -> float:
        """Determine if take-profit, stop-loss or trailing exits should trigger."""

        if position.qty <= 0:
            return 0.0

        tp_pct = self._config.take_profit_pct
        if tp_pct is not None:
            tp_price = position.average_price * (1 + tp_pct)
            if candle.high >= tp_price:
                return position.flatten()

        sl_pct = self._config.stop_loss_pct
        if sl_pct is not None:
            sl_price = position.average_price * (1 - sl_pct)
            if candle.low <= sl_price:
                return position.flatten()

        atr_multiplier = self._config.atr_trailing_multiplier
        if self._config.exit_mode == "atr_trail" and atr_multiplier is not None:
            position.high_water_mark = max(position.high_water_mark, candle.high)
            trailing_stop = position.high_water_mark - (candle.high - candle.low) * atr_multiplier
            if candle.close <= trailing_stop:
                return position.flatten()

        if self._config.exit_mode == "chandelier":
            lookback = max(1, self._config.chandelier_lookback)
            window = history[-lookback:]
            highest_high = max((c.high for c in window), default=candle.high)
            atr = self._compute_atr(window)
            if atr is not None:
                stop = highest_high - atr * self._config.chandelier_atr_mult
                if position.chandelier_stop is None or stop > position.chandelier_stop:
                    position.chandelier_stop = stop
                if (
                    position.chandelier_stop is not None
                    and candle.close <= position.chandelier_stop
                ):
                    return position.flatten()

        return 0.0

    def _update_pyramiding_state(self, candle: CandleEvent, position: _PositionState) -> None:
        if position.qty <= 0:
            position.entry_peak_price = 0.0
            position.stagnation_bars = 0
            position.adds_blocked = False
            return

        if position.entry_peak_price <= 0:
            position.entry_peak_price = candle.close

        if candle.close > position.entry_peak_price:
            position.entry_peak_price = candle.close
            position.stagnation_bars = 0
            position.adds_blocked = False
        else:
            position.stagnation_bars += 1

        reset_reason: str | None = None
        dd_threshold = self._config.pyramid_dd_reset_pct
        if (
            position.layers > 0
            and dd_threshold > 0
            and position.entry_peak_price > 0
            and candle.low < position.entry_peak_price
        ):
            drawdown = (position.entry_peak_price - candle.low) / position.entry_peak_price
            if drawdown >= dd_threshold:
                reset_reason = "dd"

        if reset_reason is None and self._config.pyramid_stagnation_bars > 0:
            if position.stagnation_bars >= self._config.pyramid_stagnation_bars:
                reset_reason = "stagnation"

        if reset_reason is not None:
            position.layers = 0
            position.chandelier_stop = None
            position.entry_peak_price = candle.close
            position.stagnation_bars = 0
            position.adds_blocked = True
            PYRAMID_RESETS.labels(symbol=candle.symbol, reason=reset_reason).inc()

    def _compute_breakout_threshold(
        self, candle: CandleEvent, history: Sequence[CandleEvent]
    ) -> float:
        history_list = list(history)
        mode = self._config.threshold_mode
        if mode == "fixed":
            return self._config.breakout_threshold
        if mode == "percentile":
            lookback = max(1, self._config.threshold_lookback)
            window = history_list[-lookback:]
            spans = [
                (c.high - c.low) / c.open
                for c in window
                if c.open > 0 and c.high >= c.low
            ]
            if spans:
                return self._percentile(spans, self._config.threshold_percentile)
            return self._config.breakout_threshold
        if mode == "atr_k":
            lookback = max(1, self._config.atr_lookback)
            window = (history_list + [candle])[-lookback:]
            tr_ratios = self._true_range_ratios(window)
            if tr_ratios:
                current_atr = sum(tr_ratios) / len(tr_ratios)
                split = self._percentile(tr_ratios, self._config.atr_percentile_split)
                k = self._config.atr_k_low if current_atr <= split else self._config.atr_k_high
                return k * current_atr
            return self._config.breakout_threshold
        return self._config.breakout_threshold

    @staticmethod
    def _percentile(values: Sequence[float], percentile: float) -> float:
        if not values:
            return 0.0
        bounded = min(max(percentile, 0.0), 1.0)
        sorted_values = sorted(values)
        if len(sorted_values) == 1:
            return sorted_values[0]
        rank = bounded * (len(sorted_values) - 1)
        lower_index = int(rank)
        upper_index = min(lower_index + 1, len(sorted_values) - 1)
        weight = rank - lower_index
        lower = sorted_values[lower_index]
        upper = sorted_values[upper_index]
        return lower * (1 - weight) + upper * weight

    @staticmethod
    def _true_range_ratios(candles: Sequence[CandleEvent]) -> list[float]:
        if not candles:
            return []
        ratios: list[float] = []
        prev_close = candles[0].open
        for candle in candles:
            tr = BreakoutBiasStrategy._true_range(candle, prev_close)
            ref_price = candle.close if candle.close > 0 else candle.open
            if ref_price <= 0:
                ratios.append(0.0)
            else:
                ratios.append(tr / ref_price)
            prev_close = candle.close
        return ratios

    @staticmethod
    def _compute_atr(candles: Sequence[CandleEvent]) -> float | None:
        if not candles:
            return None
        trs: list[float] = []
        prev_close = candles[0].open
        for candle in candles:
            trs.append(BreakoutBiasStrategy._true_range(candle, prev_close))
            prev_close = candle.close
        if not trs:
            return None
        return sum(trs) / len(trs)

    @staticmethod
    def _true_range(candle: CandleEvent, prev_close: float) -> float:
        high_low = candle.high - candle.low
        high_close = abs(candle.high - prev_close)
        low_close = abs(candle.low - prev_close)
        return max(high_low, high_close, low_close)


__all__ = ["BreakoutBiasStrategy", "StrategyConfig"]
