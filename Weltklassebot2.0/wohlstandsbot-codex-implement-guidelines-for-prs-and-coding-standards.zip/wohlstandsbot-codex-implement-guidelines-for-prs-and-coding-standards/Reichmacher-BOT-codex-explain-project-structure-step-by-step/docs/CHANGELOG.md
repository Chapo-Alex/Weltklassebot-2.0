# Changelog

## Unreleased

- Dokumentiert das erwartete Risk-Reset-Log nach Tageswechsel (UTC), um Drawdown-Freigaben nachvollziehbar zu prüfen.
