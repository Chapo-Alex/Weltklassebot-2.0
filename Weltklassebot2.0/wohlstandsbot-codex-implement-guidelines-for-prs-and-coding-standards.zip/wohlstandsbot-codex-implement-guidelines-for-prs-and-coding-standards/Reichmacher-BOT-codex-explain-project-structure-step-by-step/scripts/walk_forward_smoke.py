"""Deterministic walk-forward smoke test for the breakout strategy."""

from __future__ import annotations

import random
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from execution.adapters import MarketExecution

from core.events import CandleEvent
from strategy.breakout_bias import BreakoutBiasStrategy, StrategyConfig


@dataclass(slots=True)
class SliceResult:
    name: str
    trades: int
    hit_rate: float
    pnl: float
    max_drawdown: float


def _generate_candles(seed: int, length: int, start_price: float) -> list[CandleEvent]:
    rng = random.Random(seed)
    base = datetime(2024, 1, 1, tzinfo=UTC)
    price = start_price
    candles: list[CandleEvent] = []
    for index in range(length):
        drift = 0.0015 * (1 + (seed % 7) * 0.1)
        shock = rng.uniform(-0.003, 0.004)
        close = max(price * (1.0 + drift + shock), 1e-6)
        high = max(price, close) * (1.0 + rng.uniform(0.001, 0.004))
        low = min(price, close) * (1.0 - rng.uniform(0.001, 0.004))
        start = base + timedelta(minutes=index)
        candles.append(
            CandleEvent(
                symbol="BTCUSDT",
                open=price,
                high=high,
                low=max(low, 0.01),
                close=close,
                volume=1.0,
                start=start,
                end=start + timedelta(minutes=1),
            )
        )
        price = close
    return candles


def _run_slice(name: str, candles: list[CandleEvent], config: StrategyConfig) -> SliceResult:
    strategy = BreakoutBiasStrategy(config)
    executor = MarketExecution(fee_bps=0.5)
    orders = strategy.generate_orders(candles)

    position_qty = 0.0
    avg_price = 0.0
    cumulative = 0.0
    peak = 0.0
    max_drawdown = 0.0
    wins = 0
    trades = 0

    for order in orders:
        fill = executor.fill(order)
        if order.side == "buy":
            cumulative -= fill.fee
            notional = (avg_price * position_qty) + (fill.price * fill.qty)
            position_qty += fill.qty
            avg_price = notional / position_qty if position_qty else 0.0
        else:
            pnl = (fill.price - avg_price) * fill.qty - fill.fee
            cumulative += pnl
            wins += int(pnl > 0.0)
            trades += 1
            peak = max(peak, cumulative)
            max_drawdown = max(max_drawdown, peak - cumulative)
            position_qty = max(position_qty - fill.qty, 0.0)
            if position_qty == 0:
                avg_price = 0.0
    hit_rate = wins / trades if trades else 0.0
    return SliceResult(
        name=name,
        trades=trades,
        hit_rate=hit_rate,
        pnl=cumulative,
        max_drawdown=max_drawdown,
    )


def main() -> None:
    config = StrategyConfig(
        breakout_threshold=0.0,
        order_size=0.25,
        pyramid_steps=(1.0, 0.5),
        threshold_mode="percentile",
        threshold_percentile=0.7,
        threshold_lookback=8,
        take_profit_pct=0.02,
        exit_mode="chandelier",
        chandelier_lookback=5,
        chandelier_atr_mult=1.8,
    )

    slices = (
        ("train", 101, 32, 100.0),
        ("valid", 203, 24, 118.0),
        ("test", 307, 24, 115.0),
    )

    for name, seed, length, start_price in slices:
        candles = _generate_candles(seed, length, start_price)
        result = _run_slice(name, candles, config)
        print(
            f"[{result.name}] trades={result.trades} hit_rate={result.hit_rate:.2%} "
            f"pnl={result.pnl:.2f} max_dd={result.max_drawdown:.2f}"
        )


if __name__ == "__main__":
    main()
