"""Run a deterministic breakout-bias backtest stub."""

from __future__ import annotations

import argparse
from collections.abc import Iterable
from datetime import UTC, datetime, timedelta

from core.events import CandleEvent
from portfolio.risk import RiskContext, RiskManagerV2, RiskParameters
from strategy.breakout_bias import BreakoutBiasStrategy


def _build_candles() -> list[CandleEvent]:
    """Create a deterministic candle series for the CLI demo."""

    start = datetime(2024, 1, 1, tzinfo=UTC)
    candles: list[CandleEvent] = []
    base_price = 25_000.0
    deltas = (0.015, -0.004, 0.021, 0.0)

    for index, pct_change in enumerate(deltas):
        open_price = base_price
        close_price = round(base_price * (1 + pct_change), 2)
        high_price = max(open_price, close_price)
        low_price = min(open_price, close_price)
        end = start + timedelta(minutes=index + 1)
        candles.append(
            CandleEvent(
                symbol="BTCUSDT",
                open=open_price,
                high=high_price,
                low=low_price,
                close=close_price,
                volume=12.5 + index,
                start=start + timedelta(minutes=index),
                end=end,
            )
        )
        base_price = close_price
    return candles


def _format_decisions(strategy_orders: Iterable[str], decisions: Iterable[str]) -> str:
    """Pair order identifiers and decisions for output."""

    lines = ["Order ID               | allowed | reason"]
    lines.append("----------------------+---------+----------------------------")
    for order_line, decision_line in zip(strategy_orders, decisions, strict=False):
        lines.append(f"{order_line:<22}| {decision_line}")
    return "\n".join(lines)


def main() -> None:
    """Execute the sample backtest run."""

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--strategy",
        default="breakout_bias",
        choices=["breakout_bias"],
        help="Strategy identifier to run (currently only breakout_bias).",
    )
    args = parser.parse_args()

    if args.strategy != "breakout_bias":
        raise ValueError("Unsupported strategy requested")

    candles = _build_candles()
    strategy = BreakoutBiasStrategy()
    orders = strategy.generate_orders(candles)

    risk = RiskManagerV2(
        RiskParameters(
            max_daily_dd_pct=5.0,
            cooldown_after_loss_s=30.0,
            max_positions=5,
            max_exposure_notional=50_000.0,
            min_atr_pct=0.005,
        )
    )
    context = RiskContext(
        open_positions={},
        notional_sum=0.0,
        atr_pct_by_symbol={"BTCUSDT": 0.02},
        leverage=1.0,
    )

    order_lines: list[str] = []
    decision_lines: list[str] = []
    for order in orders:
        decision = risk.assess_new_order(order, context)
        order_lines.append(order.id)
        decision_lines.append(f"{str(decision.allow):<7} | {decision.reason}")

    print(_format_decisions(order_lines, decision_lines))


if __name__ == "__main__":
    main()
