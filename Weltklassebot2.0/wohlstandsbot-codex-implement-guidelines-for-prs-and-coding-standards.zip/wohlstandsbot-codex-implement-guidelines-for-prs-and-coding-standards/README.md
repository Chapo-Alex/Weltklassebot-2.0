# wohlstandsbot

## Architekturüberblick

```
┌───────────┐    ┌─────────────┐    ┌─────────────┐    ┌────────────────────┐    ┌──────────────────────┐    ┌──────────────┐    ┌─────────────┐
│ Datenfeeds├──▶─┤   Signals   ├──▶─┤  Strategy   ├──▶─┤ Broker/Execution   ├──▶─┤ State / Persistenz   ├──▶─┤   Exporter   ├──▶─┤  Dashboard  │
└───────────┘    └─────────────┘    └────┬────────┘    └──────┬─────────────┘    └──────────┬───────────┘    └────┬─────────┘    └────┬────────┘
                                          ▲                      │                             │                   │                  │
                                          │                      │                             │                   │                  │
                                          │            ┌─────────▼─────────┐          ┌────────▼────────┐          │                  │
                                          │            │portfolio/         │          │logs/ & stores   │          │                  │
                                          │            │(Positions & PnL)  │          │(CSV, Redis etc.)│          │                  │
                                          │            └─────────▲─────────┘          └────────▲────────┘          │                  │
                                          │                      │                             │                   │                  │
                                          │                      │                             │                   │                  │
                                          │            ┌─────────┴─────────┐          ┌────────┴────────┐          │                  │
                                          │            │risk/              │          │Prometheus-Export│          │                  │
                                          │            │(Risk-Gates)       │          │(Metriken)       │          │                  │
                                          │            └───────────────────┘          └────────────────┘          │                  │
                                          │                                                                         ▼                  ▼
                                          └─────────────────────────────── src/strategy/breakout_bias.py ────────────────────────────────
```

### Datenflüsse
- **Datenfeeds → Signals:** Die Collector-Services und externen Exchange-Streams liefern Ticks und Candles, die als `MarketEvent` bzw. `CandleEvent` in `src/core/events.py` modelliert sind. Diese Rohdaten speisen interne Signalprozesse, z. B. Bias-Adapter, News-Feeds oder technische Filter.【F:Reichmacher-BOT-codex-explain-project-structure-step-by-step/src/core/events.py†L1-L57】
- **Signals → Strategy:** Die Strategie `src/strategy/breakout_bias.py` konsumiert die erzeugten Markt- und Candle-Signale, bewertet sie mit Breakout/Bias-Heuristiken und leitet resultierende Orders an den Portfolio-Layer weiter, der auf den standardisierten Event-Strukturen aufsetzt.【F:Reichmacher-BOT-codex-explain-project-structure-step-by-step/src/core/events.py†L1-L57】
- **Strategy → Broker/Execution:** Die generierten Orders werden an den Execution-Layer (z. B. Bitget-API-Adapter) weitergereicht. Vor dem Versand greift der Portfolio-Layer (`src/portfolio/`) für Positionsabgleich und Gebührenmodelle ein.
- **Broker/Execution → State/Persistenz:** Rückmeldungen der Börse werden als `OrderEvent`/`FillEvent` verarbeitet; `portfolio/risk.py` überwacht Drawdown, Exposure und Cooldowns und verhindert Verstöße, bevor der Zustand in Redis/Dateien persistiert wird.【F:Reichmacher-BOT-codex-explain-project-structure-step-by-step/src/portfolio/risk.py†L1-L149】
- **State/Persistenz → Exporter:** Persistierte Logs (Trades, Equity, Risiko-Status) werden vom Exporter-Service eingelesen und als Prometheus-Metriken bereitgestellt.
- **Exporter → Dashboard:** Sowohl Exporter-Metriken als auch persistierte Candles/Trades speisen das Dashboard, das Kennzahlen und Equity-Kurven visualisiert.

### Einordnung zentraler Module
- `src/strategy/breakout_bias.py`: Strategie-Kern, berechnet Einstiegs-/Ausstiegsaktionen auf Basis von Breakout- und Bias-Signalen.
- `src/portfolio/`: Verwaltet Positionen, Gebührenmodelle und Übergabe an Execution; Tests in `tests/portfolio/` sichern Standardpfade ab.
- `src/portfolio/risk.py`: Zuständig für Risikolimits, Daily-Reset, Cooldowns und Statusübergänge im Trading-Betrieb.【F:Reichmacher-BOT-codex-explain-project-structure-step-by-step/src/portfolio/risk.py†L1-L149】

### Externe Abhängigkeiten & Startreihenfolge (docker-compose)
1. **Exchange-Anbindung:** Die Collector-Container verbinden sich zuerst mit dem Exchange (z. B. Bitget) und schreiben Ticks/Candles in das gemeinsame Datenvolume.
2. **Redis:** Wird als zentrales State- und Queue-Backend gestartet, bevor Engine/Strategy-Container hochfahren.
3. **Engine & Strategy:** Starten nach Redis, laden Konfiguration, aktivieren `breakout_bias` und Risk-Gates und beginnen mit Order-Emission.
4. **Exporter:** Liest Persistenzdaten der Engine und macht Prometheus-Metriken verfügbar (`/metrics`).
5. **Prometheus & Dashboard (Grafana/Streamlit):** Konsumieren Exporter-Metriken bzw. persistierte CSV/Parquet-Dateien; optionaler Stack für Monitoring/Visualisierung.

Die Compose-Definition sorgt dafür, dass Redis als Abhängigkeit markiert ist, bevor Engine/Strategy oder Exporter starten; Monitoring-Komponenten können per Profil zugeschaltet werden. Für deterministische Backtests sollten Seeds und Zeitquellen in Strategy- und Portfolio-Komponenten konsistent gesetzt werden.

## Quick Start

### 1. Lokale Installation (Python venv)
1. **Repository klonen & Projektverzeichnis betreten**
   ```bash
   git clone git@github.com:acme/wohlstandsbot.git
   cd wohlstandsbot/Reichmacher-BOT-codex-explain-project-structure-step-by-step
   ```
2. **Virtuelle Umgebung einrichten**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```
3. **Abhängigkeiten installieren**
   ```bash
   pip install --upgrade pip
   pip install -e ".[dev]"
   ```
4. **Lokale Konfiguration vorbereiten**
   ```bash
   cp .env.example .env
   # Werte gemäß Matrix unten befüllen
   ```
5. **Tests ausführen & Strategy-Backtest starten**
   ```bash
   pytest
   python scripts/run_backtest.py --strategy breakout_bias
   ```

### 2. Docker-Compose Stack
1. **Secrets & Variablen setzen** – `.env` gemäß Matrix erstellen und Docker-Secret-Dateien (z. B. `secrets/api_key`) anlegen.
2. **Images bauen**
   ```bash
   docker compose build
   ```
3. **Stack starten (inkl. Monitoring)**
   ```bash
   docker compose up -d
   ```
4. **Health prüfen**
   ```bash
   docker compose ps
   curl http://localhost:8000/health
   curl http://localhost:9090/metrics
   ```

### 3. Produktions-Checkliste
- ✅ **Secrets:** API-Keys, Webhooks und Datenbank-Credentials liegen in Docker-Secrets oder einem Secret-Manager; `.env` enthält ausschließlich Referenzen.
- ✅ **Logging:** Strukturierte JSON-Logs nach `STDOUT`; zentrale Aggregation (ELK/Loki) konfiguriert, Log-Retention ≥ 30 Tage.
- ✅ **Metriken:** Prometheus-Scrapes aktiv, Alerts für Latenz (Signals→Broker), Fehlerraten und Risk-Gate-Auslösungen vorhanden.
- ✅ **Backtest-Determinismus:** Seeds (`BACKTEST_SEED`) und Fix-Zeitquellen (`TIME_PROVIDER=static`) gesetzt und dokumentiert.
- ✅ **Deployment:** Rollout via GitOps/CI, Migration-Checks (`alembic upgrade head` falls DB) vor Freigabe.
- ✅ **Runbooks:** On-Call-Runbook mit Wiederanlaufsequenz (Exchange → Redis → Engine/Strategy → Exporter → Dashboard) gepflegt.

### `.env`-Matrix & Variablen

| Variable                | dev                        | stage                      | prod                       |
|-------------------------|---------------------------|----------------------------|----------------------------|
| `EXCHANGE_API_KEY`      | `dev-exchange-key`        | `stage-exchange-key`       | `prod-exchange-key`        |
| `EXCHANGE_API_SECRET`   | `dev-exchange-secret`     | `stage-exchange-secret`    | `prod-exchange-secret`     |
| `REDIS_URL`             | `redis://localhost:6379`  | `redis://stage-redis:6379` | `redis://prod-redis:6379`  |
| `PROMETHEUS_ENDPOINT`   | `http://localhost:9090`   | `http://prom-stage:9090`   | `http://prom-prod:9090`    |
| `BACKTEST_SEED`         | `42`                      | `1337`                     | `20240101`                 |
| `TIME_PROVIDER`         | `system`                  | `ntp`                      | `ntp`                      |
| `LOG_LEVEL`             | `DEBUG`                   | `INFO`                     | `INFO`                     |
| `ALERT_WEBHOOK_URL`     | `https://hooks.dev/...`   | `https://hooks.stage/...`  | `https://hooks.prod/...`   |
| `PORTFOLIO_RISK_LIMIT`  | `0.05`                    | `0.04`                     | `0.03`                     |

**Variablenbeschreibung**
- `EXCHANGE_API_KEY` / `EXCHANGE_API_SECRET`: Zugangsdaten für den Exchange-Adapter; in Produktion als Secrets bereitstellen.
- `REDIS_URL`: Connection-String für State- und Queue-Backend.
- `PROMETHEUS_ENDPOINT`: Ziel für Metrik-Push oder Remote-Write, z. B. für `risk_guard_trigger_total`.
- `BACKTEST_SEED`: Integer-Seed für deterministische Backtests und Simulationen.
- `TIME_PROVIDER`: Quelle für Zeitstempel (`system`, `ntp`, `static` für Tests).
- `LOG_LEVEL`: Standard-Log-Level der Engine/Strategy.
- `ALERT_WEBHOOK_URL`: Endpoint für Incident-Benachrichtigungen (z. B. Slack/Teams).
- `PORTFOLIO_RISK_LIMIT`: Maximaler Kapitalanteil pro Trade; wird in `portfolio/risk.py` für Exposure-Grenzen genutzt.

## Strategy Upgrades

```python
from datetime import UTC, datetime, timedelta

from core.events import CandleEvent
from strategy.breakout_bias import BreakoutBiasStrategy, StrategyConfig

config = StrategyConfig(
    order_size=0.2,
    pyramid_steps=(1.0, 0.5, 0.25),
    threshold_mode="atr_k",
    atr_lookback=10,
    atr_k_low=0.8,
    atr_k_high=1.6,
    atr_percentile_split=0.6,
    exit_mode="chandelier",
    chandelier_lookback=5,
    chandelier_atr_mult=2.5,
)

start = datetime(2024, 1, 1, tzinfo=UTC)
candles = [
    CandleEvent("BTCUSDT", 100.0, 101.5, 99.5, 101.2, 1.0, start, start + timedelta(minutes=1)),
    CandleEvent("BTCUSDT", 101.2, 104.5, 100.5, 104.1, 1.0, start + timedelta(minutes=1), start + timedelta(minutes=2)),
]

strategy = BreakoutBiasStrategy(config)
orders = strategy.generate_orders(candles)
```

**Flags & Hinweise**

- `threshold_mode="fixed"` entspricht dem bisherigen Verhalten; `"percentile"` nutzt Perzentile der High-Low-Spannen, `"atr_k"` schaltet je nach ATR-Regime zwischen `atr_k_low` und `atr_k_high`.
- `threshold_lookback`, `threshold_percentile`, `atr_lookback` und `atr_percentile_split` steuern die Historie bzw. Perzentil-Schwellen.
- `exit_mode="atr_trail"` verwendet `atr_trailing_multiplier`; `"chandelier"` aktiviert den neuen Chandelier-Stop mit `chandelier_lookback` und `chandelier_atr_mult`.
- `pyramid_mode="fixed"` nutzt die expliziten `pyramid_steps`; `"geometric"` erzeugt `(1.0, 0.5, 0.33, …)` bis `pyramid_max_steps` (Failsafe ≤ 8) und berücksichtigt Resets über `pyramid_dd_reset_pct` sowie `pyramid_stagnation_bars`.
- Alle Pfade bleiben deterministisch: gleiche Candle-Sequenzen erzeugen identische Orders, Seeds/Zeiten werden nicht verändert.

### Session Filters & News Freeze

- `enforce_sessions=True` aktiviert Handelszeiten-Gating; `trade_sessions` akzeptiert UTC-Zeitfenster (`"HH:MM"`), auch über Mitternacht hinweg (z. B. `("22:00", "02:00")`).
- `allow_weekends=False` blockiert Entries an Samstagen und Sonntagen (UTC), Exits bleiben aktiv.
- `news_freeze` nimmt UTC-Timestamps (`"YYYY-MM-DDTHH:MM:SSZ"`) für Sperrfenster entgegen; währenddessen werden Entries ausgelassen, Exits bleiben aktiv.
- Prometheus-Hooks (`entries_skipped_total{symbol="...",reason="session"|"news"}`) ermöglichen Observability über blockierte Trades.

## Testing & Coverage

| Kommando | Zweck |
|----------|-------|
| `pytest` | Führt Unit-, Property- und Integrationstests aus und erzeugt am Ende einen Coverage-Report für `core/`, `portfolio/`, `portfolio/risk.py` und `strategy/`. |
| `pytest --maxfail=1 -k risk` | Selektiv nur Risk-Gates testen, inklusive Coverage-Checks. |
| `ruff check` | Statische Code-Analyse entsprechend `pyproject.toml`. |
| `mypy src` | Type-Checking der produktiven Module (Python 3.11). |

Hinweise:
- Die Coverage-Konfiguration liegt im Abschnitt `[tool.reichmacher]` der `pyproject.toml` und erzwingt ≥ 85 % pro Zielpfad.
- `tests/conftest.py` instrumentiert die Testläufe ohne externe Plugins; Ausgaben erscheinen im Pytest-Report sowie im CI-Job.
- Property-Tests nutzen Hypothesis, fallen aber deterministisch auf `_hypothesis_stub` zurück, falls das Paket lokal nicht verfügbar ist.

## Test- & Observability-Playbook

- **Tests & Coverage**
  - `pytest` führt Unit-, Property- und Integrations-Tests aus; die Coverage-Zusammenfassung steht am Ende des Laufs.
- **Static Checks**
  - `ruff check` (Lint) und `mypy src` (Type-Checks) sind verpflichtend vor jedem Merge und werden im CI-Workflow ausgeführt.
- **Deterministische Zeitquellen**
  - `core.clock.DeterministicClock` liefert reproduzierbare Timestamps für Backtests; Beispiel: `python -c "from core.clock import DeterministicClock; print(DeterministicClock(start=None).now())"`.
- **Prometheus-Metriken**
  - `risk_manager_state{state="RUNNING"}` und `risk_gate_denied_total{reason="..."}` überwachen Zustandswechsel und Regelverstöße.
  - `risk_projected_exposure_notional` sowie `risk_drawdown_pct` helfen beim Alerting gegen Exposure-Überziehungen bzw. Drawdowns.
- **Health & Logging**
  - `RiskManagerV2.health_snapshot()` liefert strukturierte JSON-Daten für `/health`-Endpoints.
  - Logs werden mit Gründen für State-Transitions (`risk state transition`) versehen und sollten zentral aggregiert werden.
- **Beispielbefehle**
  - `python scripts/run_backtest.py --strategy breakout_bias --bars 100 --seed 42`
  - `curl http://localhost:9090/metrics | grep risk_manager_state`
  - `python -c "from portfolio.risk import RiskManagerV2, RiskParameters; print(RiskManagerV2(RiskParameters(5,60,5,1e5,0.001)).health_snapshot())"`